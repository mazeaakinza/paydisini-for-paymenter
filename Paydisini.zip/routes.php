<?php

use Illuminate\Support\Facades\Route;


Route::post('/paydisini/webhook', [App\Extensions\Gateways\Paydisini\Paydisini::class, 'webhook'])->name('paydisini.webhook');