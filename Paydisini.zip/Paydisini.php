<?php

namespace App\Extensions\Gateways\Paydisini;

use App\Classes\Extensions\Gateway;
use App\Helpers\ExtensionHelper;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;

class Paydisini extends Gateway
{
    public function getMetadata()
    {
        return [
            'display_name' => 'Paydisini',
            'version' => '1.1.0',
            'author' => 'Voxelox',
            'website' => 'https://voxelox.com',
        ];
    }

    public function pay($total, $products, $orderId)
    {
        $url = 'https://paydisini.co.id/api/';
        $apiKey = ExtensionHelper::getConfig('Paydisini', 'api_key');
        $merchantId = ExtensionHelper::getConfig('Paydisini', 'merchant_id');
        $serviceId = ExtensionHelper::getConfig('Paydisini', 'service_id');
        $validTime = ExtensionHelper::getConfig('Paydisini', 'valid_time');
        $typeFee = ExtensionHelper::getConfig('Paydisini', 'type_fee');
        $paymentGuide = ExtensionHelper::getConfig('Paydisini', 'payment_guide');
        $callbackCount = ExtensionHelper::getConfig('Paydisini', 'callback_count');
        $description = 'Products: ';
        foreach ($products as $product) {
            $description .= $product->name . ' x' . $product->quantity . ', ';
        }
        $response = Http::asForm()->post($url, [
            'key' => $apiKey,
            'request' => 'new',
            'merchant_id' => $merchantId,
            'unique_code' => (string) $orderId,
            'service' => $serviceId,
            'amount' => number_format($total, 0, '', ''),
            'note' => $description,
            'valid_time' => $validTime,
            'ewallet_phone' => auth()->user()->phone,
            'customer_email' => auth()->user()->email,
            'type_fee' => $typeFee == '1' ? $typeFee : '2',
            'payment_guide' => $paymentGuide ? true : false,
            'callback_count' => intval($callbackCount) <= 3 ? $callbackCount : '3',
            'return_url' => route('clients.invoice.show', $orderId),
            'signature' => md5($apiKey . $orderId . $serviceId . number_format($total, 0, '', '') . $validTime . 'NewTransaction'),
        ]);

        return $response->json()['data']['checkout_url'];
    }

    public function webhook(Request $request)
    {
        $apiKey = ExtensionHelper::getConfig('Paydisini', 'api_key');
        $apiAddress = '84.247.150.90';

        if ($request->post('key') == $apiKey && $request->ip() == $apiAddress) {
            $key = $request->post('key');
            $pay_id = $request->post('pay_id');
            $unique_code = $request->post('unique_code');
            $status = $request->post('status');
            $signature = $request->post('signature');
            $sign = md5($apiKey . $unique_code . 'CallbackStatus');
            if ($signature != $sign) {
                return response()->json(['success' => false]);
            } else if ($status == 'Success') {
                ExtensionHelper::paymentDone($unique_code, 'Paydisini');
                return response()->json(['success' => true]);
            } else if ($status == 'Canceled') {
                return response()->json(['success' => true]);
            } else {
                return response()->json(['success' => false]);
            }
        }
    }

    public function getConfig()
    {
        return [
            [
                'name' => 'api_key',
                'friendlyName' => 'API Key',
                'type' => 'text',
                'required' => true,
            ],
            [
                'name' => 'merchant_id',
                'friendlyName' => 'Merchant ID (Optional)',
                'type' => 'text',
                'required' => false,
            ],
            [
                'name' => 'service_id',
                'friendlyName' => 'ID Payment Service (1-22)',
                'type' => 'text',
                'required' => true,
            ],
            [
                'name' => 'valid_time',
                'friendlyName' => 'Payment Valid Time (300-10800)',
                'type' => 'text',
                'required' => true,
            ],
            [
                'name' => 'type_fee',
                'friendlyName' => 'Payment Fee (1 = customer, 2 = merchant)',
                'type' => 'text',
                'required' => true,
            ],
            [
                'name' => 'payment_guide',
                'friendlyName' => 'Payment Guide (Optional)',
                'type' => 'boolean',
                'required' => false,
            ],
            [
                'name' => 'callback_count',
                'friendlyName' => 'Callback Count (Optional) (Max 3)',
                'type' => 'text',
                'required' => false,
            ]
        ];
    }
}